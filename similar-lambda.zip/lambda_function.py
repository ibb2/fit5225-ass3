import base64
import boto3
import json
import src.object_detection as object_detection
from boto3.dynamodb.conditions import Key, Attr


aws_region = 'us-east-1'
boto3.setup_default_session(region_name=aws_region)

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('user_detected_objects')


def lambda_handler(event, context):

    detected_objects = object_detection.run(event['body'])

    # Perform the scan operation with the filter expression
    filter_expression = Attr('tags').contains(detected_objects)
    response = table.scan(FilterExpression=filter_expression)

    # while 'LastEvaluatedKey' in response:
    #     response = table.scan(FilterExpression=filter_expression,
    #                           ExclusiveStartKey=response['LastEvaluatedKey'])
    #     items.extend(response['Items'])

    matched_images = []
    for entity in response['Items']:
        # Assuming thumbnail URLs follow a specific pattern
        thumbnail_url = entity['tb_src_s3']
        matched_images.append(thumbnail_url)

    return {
        "isBase64Encoded": True,
        "statusCode": 200,
        "headers": {"Content-Type", "image/jpeg"},
        "body": json.dumps(event['body'])
    }
